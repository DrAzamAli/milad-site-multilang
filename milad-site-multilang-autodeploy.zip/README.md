# 🌙 Jashn-e-Eid Milad-un-Nabi ﷺ Website

This is a multilingual website (Urdu, Hindi, English) created for **Barhavi Shareef & Eid Milad-un-Nabi ﷺ**.

## 🚀 Deployment (Automatic)
This repo is preconfigured with **GitHub Pages auto-deploy**.  
As soon as you push/upload to a GitHub repo, the site will publish automatically at:

```
https://<your-username>.github.io/<your-repo-name>/
```

### Steps:
1. Create a new repository on GitHub (e.g. `milad-site-multilang`).
2. Upload all files from this folder (including `.github/workflows/deploy.yml`).
3. Go to **Settings → Pages** in GitHub → set "Source" to "GitHub Actions".  
4. Done ✅ Your site will be live within 1-2 minutes.

---
© 2025 Designed with ❤️ for Eid Milad-un-Nabi ﷺ
